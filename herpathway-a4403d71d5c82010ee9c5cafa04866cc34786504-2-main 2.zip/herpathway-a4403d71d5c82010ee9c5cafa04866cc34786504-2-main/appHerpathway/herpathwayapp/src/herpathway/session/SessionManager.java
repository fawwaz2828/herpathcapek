package herpathway.session;


import java.io.*;
import java.nio.file.*;

public class SessionManager {
    private static SessionManager instance;
    private long currentUserId;
    private String currentUserUsername;

    private static final String SESSION_FILE_PATH = "session.csv";
    private static final String CSV_DELIMITER = ",";

    private SessionManager() {
        loadSessionFromFile();
    }

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void setCurrentUser(long userId, String username) {
        this.currentUserId = userId;
        this.currentUserUsername = username;
        saveSessionToFile();
    }

    public long getCurrentUserId() {
        return currentUserId;
    }

    public String getCurrentUserUsername() {
        return currentUserUsername;
    }

    private void saveSessionToFile() {
        String sessionRecord = String.join(CSV_DELIMITER, String.valueOf(currentUserId), currentUserUsername);

        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(SESSION_FILE_PATH), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
            writer.write(sessionRecord);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadSessionFromFile() {
        if (Files.exists(Paths.get(SESSION_FILE_PATH))) {
            try (BufferedReader reader = Files.newBufferedReader(Paths.get(SESSION_FILE_PATH))) {
                String line = reader.readLine();
                if (line != null) {
                    String[] sessionFields = line.split(CSV_DELIMITER);
                    if (sessionFields.length == 2) {
                        this.currentUserId = Long.parseLong(sessionFields[0]);
                        this.currentUserUsername = sessionFields[1];
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
