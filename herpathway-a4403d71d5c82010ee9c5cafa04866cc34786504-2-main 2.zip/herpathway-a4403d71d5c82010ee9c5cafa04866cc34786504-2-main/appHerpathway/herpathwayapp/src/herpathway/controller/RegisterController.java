package herpathway.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import herpathway.database.UserDatabase;

public class RegisterController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private PasswordField confirmPasswordField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField passwordTextField;

    @FXML
    private TextField confirmPasswordTextField;

    @FXML
    private CheckBox showPasswordToggle;

    @FXML
    private ComboBox<String> userTypeComboBox;

    private String[] userType = {"mentee", "mentor", "organization"};

    @FXML
    protected void handleShowPasswordAction(ActionEvent event) {
        boolean showPassword = showPasswordToggle.isSelected();
        passwordTextField.setText(passwordField.getText());
        confirmPasswordTextField.setText(confirmPasswordField.getText());

        passwordTextField.setVisible(showPassword);
        passwordTextField.setManaged(showPassword);
        confirmPasswordTextField.setVisible(showPassword);
        confirmPasswordTextField.setManaged(showPassword);

        passwordField.setVisible(!showPassword);
        passwordField.setManaged(!showPassword);
        confirmPasswordField.setVisible(!showPassword);
        confirmPasswordField.setManaged(!showPassword);
    }

    @FXML
    protected void handleRegisterButtonAction(ActionEvent event) {
        String username = usernameField.getText();
        String password = showPasswordToggle.isSelected() ? passwordTextField.getText() : passwordField.getText();
        String confirmPassword = showPasswordToggle.isSelected() ? confirmPasswordTextField.getText() : confirmPasswordField.getText();
        String email = emailField.getText();
        String userType = userTypeComboBox.getValue();

        // Validasi email
        if (!isValidEmail(email)) {
            showAlert("Registration Failed", "Format email tidak valid. Harap masukkan alamat email yang benar.");
            return;
        }

        // Validasi password
        if (password.length() < 8) {
            showAlert("Registration Failed", "Password harus terdiri dari setidaknya 8 karakter.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            showAlert("Registration Failed", "Password tidak cocok.");
            return;
        }

        try {
            if (UserDatabase.userExists(username)) {
                showAlert("Registration Failed", "Username sudah ada.");
            } else {
                UserDatabase.addUser(username, password, email, userType);
                showAlert("Registration Successful", "Pendaftaran pengguna berhasil.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Terjadi kesalahan saat menyimpan informasi pengguna: " + e.getMessage());
        }
    }

    @FXML
    public void initialize() {
        initializeComboBox(userTypeComboBox);
    }

    private void initializeComboBox(ComboBox<String> comboBox) {
        comboBox.getItems().addAll(userType);
        comboBox.setValue(userType[0]);
    }

    @FXML
    protected void handleBackToLoginLinkAction(ActionEvent event) {
        Stage stage = (Stage) usernameField.getScene().getWindow();
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/herpathway/view/LoginView.fxml"));
            stage.setScene(new Scene(root, 300, 200));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Terjadi kesalahan saat memuat halaman login: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
