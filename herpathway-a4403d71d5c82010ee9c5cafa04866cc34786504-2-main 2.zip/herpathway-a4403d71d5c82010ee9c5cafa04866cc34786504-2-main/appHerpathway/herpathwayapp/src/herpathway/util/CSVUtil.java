package herpathway.util;

import java.io.*;
import java.util.HashSet;
import java.util.Set;

public class CSVUtil {
    private static final String CSV_FILE_PATH = "user_logins.csv";

    public static void saveLoginInfoToCSV(String username, String userType) {
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(CSV_FILE_PATH, true)))) {
            StringBuilder sb = new StringBuilder();
            sb.append(username);
            sb.append(',');
            sb.append(userType);
            sb.append(',');
            sb.append(System.currentTimeMillis());
            sb.append('\n');
            writer.write(sb.toString());
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Terjadi kesalahan saat menyimpan informasi login: " + e.getMessage());
        }
    }

    public static boolean userExists(String username) throws IOException {
        Set<String> usernames = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                if (tokens.length > 0) {
                    usernames.add(tokens[0]);
                }
            }
        }
        return usernames.contains(username);
    }

    public static void addUser(String username, String password, String email, String userType) throws IOException {
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(CSV_FILE_PATH, true)))) {
            StringBuilder sb = new StringBuilder();
            sb.append(username);
            sb.append(',');
            sb.append(password); // Pastikan untuk mengenkripsi password sebelum menyimpannya di aplikasi nyata.
            sb.append(',');
            sb.append(email);
            sb.append(',');
            sb.append(userType);
            sb.append(',');
            sb.append(System.currentTimeMillis());
            sb.append('\n');
            writer.write(sb.toString());
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Terjadi kesalahan saat menyimpan informasi pengguna: " + e.getMessage());
        }
    }

    public static long validateUser(String username, String password) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                if (tokens.length > 1 && tokens[0].equals(username) && tokens[1].equals(password)) {
                    return Long.parseLong(tokens[4]); // Mengembalikan waktu sebagai ID pengguna
                }
            }
        }
        return -1; // Login gagal
    }

    public static String getUserType(String username) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                if (tokens.length > 3 && tokens[0].equals(username)) {
                    return tokens[3]; // Mengembalikan tipe pengguna
                }
            }
        }
        return null; // Atau lemparkan pengecualian jika pengguna tidak ditemukan
    }

    public static long getUserId(String username) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                if (tokens.length > 0 && tokens[0].equals(username)) {
                    return Long.parseLong(tokens[4]); // Mengembalikan waktu sebagai ID pengguna
                }
            }
        }
        throw new IOException("Pengguna tidak ditemukan"); // Atau bisa mengembalikan nilai yang sesuai jika pengguna tidak ditemukan
    }

    private static void showAlert(String title, String message) {
        System.out.println(title + ": " + message);
    }
}
