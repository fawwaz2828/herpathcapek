package com.herpathway.controller;

import com.herpathway.database.DatabaseHandler;
import com.herpathway.session.SessionManager;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MentorshipQuestionController {

    @FXML
    private RadioButton veryExperiencedRadioButton;

    @FXML
    private RadioButton experiencedRadioButton;

    @FXML
    private RadioButton neutralRadioButton;

    @FXML
    private RadioButton inexperiencedRadioButton;

    @FXML
    private RadioButton veryInexperiencedRadioButton;

    @FXML
    private CheckBox networkingCheckBox;

    @FXML
    private CheckBox learningSkillsCheckBox;

    @FXML
    private CheckBox careerAdviceCheckBox;

    @FXML
    private CheckBox personalDevelopmentCheckBox;

    @FXML
    private TextArea suggestionsTextArea;

    @FXML
    private VBox parentVBox; // Parent container for navigation

    private ToggleGroup experiencedLevelToggleGroup;

    @FXML
    public void initialize() {
        // Initialize radio buttons toggle group
        experiencedLevelToggleGroup = new ToggleGroup();
        veryExperiencedRadioButton.setToggleGroup(experiencedLevelToggleGroup);
        experiencedRadioButton.setToggleGroup(experiencedLevelToggleGroup);
        neutralRadioButton.setToggleGroup(experiencedLevelToggleGroup);
        inexperiencedRadioButton.setToggleGroup(experiencedLevelToggleGroup);
        veryInexperiencedRadioButton.setToggleGroup(experiencedLevelToggleGroup);
    }

    @FXML
    private void handleSubmitButtonAction() {
        // Validate form data
        if (!isFormValid()) {
            return;
        }

        // Collect data from the form
        String experiencedLevel = getSelectedExperiencedLevel();
        String beneficialAspects = getSelectedBeneficialAspects();
        String suggestions = suggestionsTextArea.getText();
        String satisfactionLevel = getSelectedSatisfactionLevel();

        // Get current user information from session
        long userId = SessionManager.getInstance().getCurrentUserId();
        String username = SessionManager.getInstance().getCurrentUserUsername();

        // Save data to the database
        saveToDatabase(userId, username, experiencedLevel, beneficialAspects, suggestions, satisfactionLevel);

        // Clear form
        clearForm();

        // Optionally, show a success message or navigate to another page
        // showMessage("Form submitted successfully!");
    }

    private boolean isFormValid() {
        // Implement your form validation logic here
        // For example, ensure that at least one radio button and one checkbox are selected
        if (experiencedLevelToggleGroup.getSelectedToggle() == null) {
            // Show an alert or message to inform the user to select an experienced level
            // showMessage("Please select your experience level.");
            return false;
        }

        if (!networkingCheckBox.isSelected() && !learningSkillsCheckBox.isSelected() &&
                !careerAdviceCheckBox.isSelected() && !personalDevelopmentCheckBox.isSelected()) {
            // Show an alert or message to inform the user to select at least one beneficial aspect
            // showMessage("Please select at least one beneficial aspect.");
            return false;
        }

        return true;
    }

    private void saveToDatabase(long userId, String username, String experiencedLevel, String beneficialAspects, String suggestions, String satisfactionLevel) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            // Get a connection to the database
            conn = DatabaseHandler.getConnection();

            // Prepare SQL statement
            String sql = "INSERT INTO kuisoner (user_id, username, experienced_level, beneficial_aspects, suggestions, satisfaction_level) VALUES (?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setLong(1, userId);
            stmt.setString(2, username);
            stmt.setString(3, experiencedLevel);
            stmt.setString(4, beneficialAspects);
            stmt.setString(5, suggestions);
            stmt.setString(6, satisfactionLevel);

            // Log the SQL statement and parameters (optional for debugging)
            System.out.println("Executing SQL: " + stmt.toString());

            // Execute the statement
            stmt.executeUpdate();

            // Optionally, show a success message or navigate to another page
            // showMessage("Data saved successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error executing SQL: " + e.getMessage());
            // Optionally, show an error message to the user
            // showMessage("Error saving data. Please try again later.");
        } finally {
            // Close the statement and connection
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private String getSelectedExperiencedLevel() {
        RadioButton selectedRadioButton = (RadioButton) experiencedLevelToggleGroup.getSelectedToggle();
        if (selectedRadioButton != null) {
            return selectedRadioButton.getText();
        }
        return "";
    }

    private String getSelectedBeneficialAspects() {
        StringBuilder selectedAspects = new StringBuilder();
        if (networkingCheckBox.isSelected()) {
            selectedAspects.append("Networking opportunities, ");
        }
        if (learningSkillsCheckBox.isSelected()) {
            selectedAspects.append("Learning new skills, ");
        }
        if (careerAdviceCheckBox.isSelected()) {
            selectedAspects.append("Career advice, ");
        }
        if (personalDevelopmentCheckBox.isSelected()) {
            selectedAspects.append("Personal development, ");
        }
        // Remove trailing comma and space
        return selectedAspects.length() > 0 ? selectedAspects.substring(0, selectedAspects.length() - 2) : "";
    }

    private String getSelectedSatisfactionLevel() {
        if (veryExperiencedRadioButton.isSelected()) {
            return "very satisfied";
        } else if (experiencedRadioButton.isSelected()) {
            return "satisfied";
        } else if (neutralRadioButton.isSelected()) {
            return "neutral";
        } else if (inexperiencedRadioButton.isSelected()) {
            return "dissatisfied";
        } else if (veryInexperiencedRadioButton.isSelected()) {
            return "very dissatisfied";
        }
        return "";
    }

    private void clearForm() {
        // Clear all selections and text fields
        experiencedLevelToggleGroup.selectToggle(null);
        veryExperiencedRadioButton.setSelected(false);
        experiencedRadioButton.setSelected(false);
        neutralRadioButton.setSelected(false);
        inexperiencedRadioButton.setSelected(false);
        veryInexperiencedRadioButton.setSelected(false);
        networkingCheckBox.setSelected(false);
        learningSkillsCheckBox.setSelected(false);
        careerAdviceCheckBox.setSelected(false);
        personalDevelopmentCheckBox.setSelected(false);
        suggestionsTextArea.clear();
    }

    // Optionally, you can add methods for showing messages or handling UI interactions
    // For example:
    /*
    private void showMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    */
}
